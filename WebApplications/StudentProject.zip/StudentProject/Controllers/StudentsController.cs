using Microsoft.AspNetCore.Mvc;
using StudentProject.Models;
using StudentProject.Services;

namespace StudentProject.Controllers
{
    public class StudentsController : Controller
    {
        private readonly IStudentService _service;

        public StudentsController(IStudentService service)
        {
            _service = service;
        }

        public async Task<IActionResult> Index(string q)
        {
            ViewBag.Query = q;
            var students = await _service.SearchAsync(q);
            return View(students);
        }

        [HttpGet]
        public async Task<IActionResult> Search(string q)
        {
            var students = await _service.SearchAsync(q);
            return Json(students);
        }

        public async Task<IActionResult> Details(int? id)
        {
            if (id is null)
                return NotFound();

            var student = await _service.GetByIdAsync(id.Value);
            if (student is null)
                return NotFound();

            return View(student);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("FullName,Email,Phone,JoinDate")] Student student)
        {
            ModelState.Remove("Status");

            if (ModelState.IsValid)
            {
                student.Status = "Active";
                student.CreatedAt = DateTime.Now;
                await _service.AddAsync(student);
                return RedirectToAction(nameof(Index));
            }
            return View(student);
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id is null)
                return NotFound();

            var student = await _service.GetByIdAsync(id.Value);
            if (student is null)
                return NotFound();

            return View(student);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("StudentId,FullName,Email,Phone,Status,JoinDate,CreatedAt")] Student student)
        {
            if (id != student.StudentId)
                return NotFound();

            if (ModelState.IsValid)
            {
                await _service.UpdateAsync(student);
                return RedirectToAction(nameof(Index));
            }
            return View(student);
        }

        public async Task<IActionResult> Delete(int? id)
        {
            if (id is null)
                return NotFound();

            var student = await _service.GetByIdAsync(id.Value);
            if (student is null)
                return NotFound();

            return View(student);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            await _service.DeleteAsync(id);
            return RedirectToAction(nameof(Index));
        }
    }
}
