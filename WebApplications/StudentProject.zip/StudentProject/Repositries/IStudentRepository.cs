﻿using StudentProject.Models;

namespace StudentProject.Repositries
{
    public interface IStudentRepository
    {
        Task<List<Student>> GetAllAsync(string q = null);
        Task<Student?> GetByIdAsync(int id);
        Task AddAsync(Student student);
        Task UpdateAsync(Student student);
        Task DeleteAsync(int id);
    }
}
